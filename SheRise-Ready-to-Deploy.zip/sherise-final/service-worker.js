// SheRise Service Worker v1.0
const CACHE = 'sherise-v1';

// Files to cache for offline use
const PRECACHE = [
  '/',
  '/index.html',
  '/manifest.json',
  '/icon.svg'
];

// ── Install: cache core files ──
self.addEventListener('install', e => {
  e.waitUntil(
    caches.open(CACHE)
      .then(c => c.addAll(PRECACHE.map(u => new Request(u, {cache:'reload'}))))
      .then(() => self.skipWaiting())
  );
});

// ── Activate: remove old caches ──
self.addEventListener('activate', e => {
  e.waitUntil(
    caches.keys()
      .then(keys => Promise.all(
        keys.filter(k => k !== CACHE).map(k => caches.delete(k))
      ))
      .then(() => self.clients.claim())
  );
});

// ── Fetch: cache-first for app, network-first for fonts ──
self.addEventListener('fetch', e => {
  const url = new URL(e.request.url);

  // Skip non-GET, browser-extension, and analytics requests
  if (e.request.method !== 'GET') return;
  if (url.protocol === 'chrome-extension:') return;
  if (url.hostname.includes('google-analytics')) return;

  // Google Fonts — network first, cache fallback
  if (url.hostname.includes('fonts.')) {
    e.respondWith(
      fetch(e.request)
        .then(r => { caches.open(CACHE).then(c => c.put(e.request, r.clone())); return r; })
        .catch(() => caches.match(e.request))
    );
    return;
  }

  // Everything else — cache first, network fallback
  e.respondWith(
    caches.match(e.request).then(cached => {
      if (cached) return cached;
      return fetch(e.request).then(r => {
        if (r && r.status === 200) {
          caches.open(CACHE).then(c => c.put(e.request, r.clone()));
        }
        return r;
      }).catch(() => {
        // Offline fallback: return app shell for navigation
        if (e.request.mode === 'navigate') return caches.match('/index.html');
      });
    })
  );
});

// ── Background sync for SOS (future) ──
self.addEventListener('sync', e => {
  if (e.tag === 'sherise-sos') {
    e.waitUntil(retrySOS());
  }
});

async function retrySOS() {
  const pending = await self.registration.getNotifications({tag:'sherise-sos'});
  console.log('SheRise SW: retrying pending SOS if any', pending.length);
}
